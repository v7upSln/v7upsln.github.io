import os

# iOS/jailbreak specific paths
PSVMP_DIR = "/var/mobile/Library/PSVMP"
TEMP_FOLDER = os.path.join(PSVMP_DIR, "temp")
CONVERTED_FOLDER = os.path.join(PSVMP_DIR, "converted")
LOG_FOLDER = os.path.join(PSVMP_DIR, "logs")

# Default configuration
DEFAULT_CONFIG = {
    "vita_ip": "192.168.1.7",
    "vita_port": 1337,
    "video_path": "ux0:/video/shows/",
    "music_path": "ux0:/music/",
    "max_retries": 5,
    "retry_delay": 3
}

HISTORY_FILE = os.path.join(PSVMP_DIR, "history.log")

DEFAULT_VITA_IP = DEFAULT_CONFIG["vita_ip"]
DEFAULT_VITA_PORT = DEFAULT_CONFIG["vita_port"]
VITA_VIDEO_PATH = DEFAULT_CONFIG["video_path"]
VITA_MUSIC_PATH = DEFAULT_CONFIG["music_path"]
MAX_RETRIES = DEFAULT_CONFIG["max_retries"]
RETRY_DELAY = DEFAULT_CONFIG["retry_delay"]

# Create directories if they don't exist
os.makedirs(PSVMP_DIR, exist_ok=True)
os.makedirs(TEMP_FOLDER, exist_ok=True)
os.makedirs(CONVERTED_FOLDER, exist_ok=True)
os.makedirs(LOG_FOLDER, exist_ok=True)